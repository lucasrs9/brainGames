angular.module('brainGames.usuario').controller(function ($scope) {
    
});