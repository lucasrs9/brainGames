'use strict';

var brainGames = angular.module('brainGames', ['ngRoute', 'ui.bootstrap']);