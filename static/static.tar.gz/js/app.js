var brainGames = angular.module('brainGames', ['ngRoute', 'ui.bootstrap']);
'use strict';